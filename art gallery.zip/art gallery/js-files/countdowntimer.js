var timerCount = 10;
    var redirectTimer = setInterval(function(){
    timerCount--;
    document.getElementById("countdowntimer").textContent = timerCount;
    if(timerCount <= 0)
        clearInterval(redirectTimer);
    },1000);