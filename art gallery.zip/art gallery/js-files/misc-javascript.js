AFRAME.registerComponent('hello-world', {
  init: function () {
    console.log('Loading misc-js file...');
  }
});

Hyperlink component (use a-link="google.com")
AFRAME.registerComponent('a-link', {
  schema: {default: ''},

  init: function () {
    var url = this.data;
    //var target = this.el.getAttribute('target');
    this.el.addEventListener('click', function () {
    //window.location.href = url;
    window.open(url,  "_blank", "width: 100%; height: 100%", "");
 });
 
});

document.querySelector('#galleryImage1').addEventListner('mouseenter', function() {
    window.open(url,  "_blank", "width: 100%; height: 100%", "");
});