// angular module defintion \\
var app = angular.module('myApp', []);
// controller - MyCtrl \\
app.controller('MyCtrl', function($scope) {
	console.log("body");
	var gallery = ["images/seaImage1.jpeg"];
	var index = 0;
	$scope.galleryOpen = true;
	console.log("gallery", gallery);
	
	
	$scope.openGallery = function() {
	    $scope.galleryOpen = true;
		// Gets the JSON data from JSON file \\
		$.getJSON('js-files/gallery.json', function(data) {
			console.log("data", data.images);
			gallery = data.images;
			console.log("gallery", gallery);
			return false;
		});
		$scope.currImage = gallery[index];
		console.log("image array", $scope.currImage);
		$('#id01').css('display' , 'block');
		console.log("The current image is: " , $scope.currImage);
	}
// next image \\
$scope.nextImage = function() {
if(index < gallery.length) {
    index++;
    $scope.currImage = gallery[index];
    console.log(index);
    console.log("The current image is: " , $scope.currImage);
    }
}
// prev image \\
$scope.prevImage = function() {
    if(index > 0) {
        index--;
        $scope.currImage = gallery[index];
        console.log(index);
        console.log("The current image is: " , $scope.currImage);
    }
    if(index = 0) {
        index = 0;
       console.log(index);
       console.log("The current image is: " , $scope.currImage);
    }
}

});



/* 

*/